from objects import GameObject
class Camera(GameObject):
    def __init__(self):
        super().__init__((0, 0), [[[0,0],[0,0],[0,0]]], 0)
   
    def projection(self, vertexes):
        projected_vertexes = []
        for vertex in vertexes:
            projected_vertexes.append([vertex[0] - self.transform.x, vertex[1] - self.transform.y])
        return projected_vertexes