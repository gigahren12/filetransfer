from abc import ABC, abstractmethod

class Component(ABC):
    @abstractmethod
    def update(self):
        pass

class TransformComponent(Component):
    def __init__(self, coordinates, shape):
        self.x, self.y = coordinates
        self.shape = shape

    def move_on(self, coordinates):
        self.x, self.y = coordinates

    def get_coordinates(self):
        return (self.x, self.y)

    def update(self):
        pass
