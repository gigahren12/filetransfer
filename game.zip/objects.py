from components import TransformComponent
class GameObject:
    next_id = 0
    def __init__(self, coordinates, shape, layer=0):
        self.id = GameObject.next_id
        self.layer = layer
        GameObject.next_id += 1
        self.transform = TransformComponent(coordinates, shape)
        self.components = []

    def add_component(self, component):
        self.components.append(component)
    
    def remove_component(self, component):
        self.components.remove(component)
    
    def update(self):
        for c in self.components:
            c.update()
