from camera import Camera
class Scene:
    def __init__(self, app):
        self.objects = {}
        self.app = app
        self.camera = self.get_obj(self.add_obj(Camera())) 

    def get_obj(self, obj_number):
        return self.objects[obj_number]

    def add_obj(self, obj):
        self.objects[obj.id] = obj
        return obj.id
    
    def remove_obj(self, obj_number):
        self.objects.remove(obj_number)
    
    def update_frame(self):
        for obj in self.objects:
            self.objects[obj].update()