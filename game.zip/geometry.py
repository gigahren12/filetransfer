from abc import ABC, abstractmethod

class Shape(ABC):
    def __init__(self):
        pass
   
    def __iter__(self):
        pass

    def __next__(self):
        pass

class Square(Shape):
    def __init__(self, size):
        self.vertexes = [[[0, 0], [size, size], [0,size]], [[0, 0], [size, size], [size, 0]]]
        self.c = -1
    
    def __iter__(self):
        self.c = -1
        return self
    
    def __next__(self):
        if self.c == 1:
            raise StopIteration
        self.c += 1
        return self.vertexes[self.c]