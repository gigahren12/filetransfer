from renderer import *
import os

class App:
    def __init__(self, name, win_size):
        self.scenes = []
        self.scene = None
        self.current_scene = 0
        self.renderer = Renderer(win_size, name)

    def add_scene(self, scene):
        self.scenes.append(scene)
        return len(self.scenes) - 1

    def set_scene(self, n_scene):
        self.scene = n_scene
        os.system('clear')
        self.renderer.render(self.scenes[self.scene])

    def update_frame(self):
        self.scenes[self.scene].update_frame()
        os.system('clear')
        self.renderer.render(self.scenes[self.scene])