import pygame

# Initialize Pygame
pygame.init()

class Renderer:
    def __init__(self, window_size, window_name):
        # Set up the game window
        self.screen = pygame.display.set_mode(window_size)
        pygame.display.set_caption(window_name)
    
    def projection(self, vertexes, obj, camera):
        projected_vertexes = []
        for vertex in vertexes:
            projected_vertexes.append([vertex[0] + obj.transform.x, vertex[1] + obj.transform.y])
        return camera.projection(projected_vertexes) 
    
    def render(self, scene):
        self.screen.fill((0, 0, 0))
        render_queue = []
        for obj in scene.objects:
            render_queue.append(scene.objects[obj])
        render_queue.sort(key=lambda x: x.layer)
        for obj in render_queue:
            for polygon in obj.transform.shape:
                vertexes = self.projection(polygon, obj, scene.camera)
                pygame.draw.polygon(self.screen, (255, 255, 255), vertexes)
        pygame.display.update()