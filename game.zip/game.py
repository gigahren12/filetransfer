from engine import App
from world import Scene
from objects import GameObject
from components import Component
from geometry import Square
import pygame
import random 
pygame.init()
class PlayerController(Component):
    def __init__(self, obj, scene):
        self.obj = obj
        self.scene = scene

    def update(self):
        self.scene.camera.transform.move_on(self.obj.transform.get_coordinates())

class CameraController(Component):
    def __init__(self, obj):
        self.obj = obj

    def update(self):
        pass

class Player(GameObject):
    def __init__(self, x, y):
        super().__init__((x, y), Square(100), 0)

engine = App('game', (800, 600))
game_scene = Scene(engine)
player = Player(100, 100)
player.add_component(PlayerController(player,game_scene))
game_scene.add_obj(player)
game_scene.camera.add_component(CameraController(game_scene.camera)) 
game_scene = engine.add_scene(game_scene)
engine.set_scene(game_scene)
while True:
    engine.update_frame()
